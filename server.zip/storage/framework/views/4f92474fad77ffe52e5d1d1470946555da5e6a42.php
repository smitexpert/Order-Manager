<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Add Order</h1>
		</div>
    </div><!--/.row-->
    
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <div class="alert-title">Success</div>
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <form class="form-horizontal row-border" method="POST" action="<?php echo e(route('add.store')); ?>">
        <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">Add Customer Info</div>
                <div class="panel-body">
                        <div class="form-group">
                            <label class="col-md-2 control-label">Select Shop</label>
                            <div class="col-md-10">
                                <select class="form-control" name="shop" id="shop" value="<?php echo e(old('shop')); ?>" required>
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($shop->id); ?>" <?php if(Session::has('shop')): ?>
                                            <?php if(Session::get('shop') == $shop->id): ?>
                                                selected
                                            <?php endif; ?>
                                            <?php endif; ?>><?php echo e($shop->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Customer Name</label>
                            <div class="col-md-10">
                                <input type="text" name="customerName" value="<?php echo e(old('customerName')); ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Customer Mobile</label>
                            <div class="col-md-10">
                                <input type="text" name="customerMobile" value="<?php echo e(old('customerMobile')); ?>" class="form-control" pattern="[0-9]{11}" minlength="11" maxlength="11" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Customer Address</label>
                            <div class="col-md-10">
                                <input type="text" name="customerAddress" value="<?php echo e(old('customerAddress')); ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Customer District</label>
                            <div class="col-md-10">
                                <select name="customerDistrict" id="customerDistrict" class="form-control"  data-live-search="true">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($district->name); ?>"><?php echo e($district->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Select Courier</label>
                            <div class="col-md-10">
                                <select class="form-control" id="courier" name="courier" value="<?php echo e(old('courier')); ?>" required>
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($courier->id); ?>"><?php echo e($courier->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading clearfix">Add Product Info</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="col-md-12">Product Name</label>
                                    <div class="col-md-12">
                                        <input type="text" name="productName" value="<?php echo e(old('productName')); ?>" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-12">Product Price</label>
                                    <div class="col-md-12">
                                        <input type="text" onkeyup="getTotal()" id="productPrice" name="productPrice" value="<?php echo e(old('productPrice')); ?>" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="col-md-12">Product Quantity</label>
                                    <div class="col-md-12">
                                        <input type="number" min="1" onkeyup="getTotal()" id="productQuantity" name="productQuantity" value="<?php echo e(old('productQuantity')); ?>" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="col-md-12">Shipping Charge</label>
                                    <div class="col-md-12">
                                        <input type="text" onkeyup="getTotal()" id="shippingCharge" name="shippingCharge" value="<?php echo e(old('shippingCharge')); ?>" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="col-md-12">Discount</label>
                                    <div class="col-md-12">
                                        <input type="text" onkeyup="getTotal()" id="discount" name="discount" value="<?php echo e(old('discount')); ?>" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="col-md-12">Total Charge</label>
                                    <div class="col-md-12">
                                        <input type="text" id="totalCharge" name="totalCharge" value="<?php echo e(old('totalCharge')); ?>" class="form-control" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="col-md-12">Delivery Date</label>
                                    <div class="col-md-12">
                                        <input type="date" name="deliveryDate" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-success">Add Order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){

            $('#customerDistrict').selectpicker();

            if($('#productPrice').val() == ''){
                $('#productPrice').val(0);
            }
            if($('#productQuantity').val() == ''){
                $('#productQuantity').val(1);
            }
            if($('#shippingCharge').val() == ''){
                $('#shippingCharge').val(0);
            }
            if($('#discount').val() == ''){
                $('#discount').val(0);
            }
            if($('#totalCharge').val() == ''){
                $('#totalCharge').val(0);
            }

            $("#courier").change(function(){
                var id = $(this).val();
                if(id != ""){
                    $.ajax({
                        url: "<?php echo e(url('/')); ?>/add/"+id+"/charge",
                        method: 'get',
                        success: function(data){
                            $("#shippingCharge").val(data.charge);
                            getTotal();
                        }
                    });
                }
            });
            
        })

        function getTotal(){
            var productPrice = $('#productPrice').val();
            var productQuantity = $('#productQuantity').val();
            var shippingCharge = $('#shippingCharge').val();
            var discount = $('#discount').val();
            // var total = ((productPrice*productQuantity)+shippingCharge)-discount;
            var total = ((parseFloat(productPrice)*parseInt(productQuantity))+parseInt(shippingCharge))-parseInt(discount);
            $("#totalCharge").val(total);
        }

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\ordermanager\resources\views/backend/addorder/index.blade.php ENDPATH**/ ?>