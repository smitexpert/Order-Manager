<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <div class="profile-sidebar">
        <div class="profile-usertitle">
            <div class="profile-usertitle-name"><?php echo e(Auth::user()->name); ?></div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="divider"></div>
    <ul class="nav menu">
    <li class="<?php echo e((Route::currentRouteName() == 'dashboard') ? 'active' : ''); ?><?php echo e((Route::currentRouteName() == 'home') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'add') ? 'active' : ''); ?>"><a href="<?php echo e(route('add')); ?>"><em class="fa fa-calendar-plus-o">&nbsp;</em> Add Order</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'all') ? 'active' : ''); ?>"><a href="<?php echo e(route('all')); ?>"><em class="fa fa-search">&nbsp;</em> Find Order</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'pending') ? 'active' : ''); ?>"><a href="<?php echo e(route('pending')); ?>"><em class="fa fa-hourglass-half">&nbsp;</em> Pending Order</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'shipped') ? 'active' : ''); ?>"><a href="<?php echo e(route('shipped')); ?>"><em class="fa fa-paper-plane">&nbsp;</em> Shipped Order</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'printed') ? 'active' : ''); ?>"><a href="<?php echo e(route('printed')); ?>"><em class="fa fa-print">&nbsp;</em> Printed Order</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'courier') ? 'active' : ''); ?>"><a href="<?php echo e(route('courier')); ?>"><em class="fa fa-bicycle">&nbsp;</em> Courier Services</a></li>
        <li class="<?php echo e((Route::currentRouteName() == 'shop') ? 'active' : ''); ?>"><a href="<?php echo e(route('shop')); ?>"><em class="fa fa-shopping-cart">&nbsp;</em> Shop Manager</a></li>
    </ul>
</div><!--/.sidebar--><?php /**PATH D:\LARAVEL\ordermanager\resources\views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>