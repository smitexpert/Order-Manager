<?php $__env->startSection('content'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Courier Services</h1>
		</div>
    </div><!--/.row-->

    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <div class="alert-title">Success</div>
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <form class="form-horizontal row-border" method="POST" action="<?php echo e(route('courier.store')); ?>">
        <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">Add Courier Info</div>
                <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group <?php if ($errors->has('courierName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('courierName'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                    <label class="col-md-12">Courier Name</label>
                                    <div class="col-md-12">
                                        <input type="text" name="courierName" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group <?php if ($errors->has('courierCharge')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('courierCharge'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                    <label class="col-md-12">Charge</label>
                                    <div class="col-md-12">
                                        <input type="text" name="courierCharge" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <br>
                                <button class="btn btn-success btn-lg">Add</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">Courier List</div>
                <div class="panel-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Charge</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                                    <td><?php echo e($courier->name); ?></td>
                                    <td><?php echo e($courier->charge); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="#" class="btn btn-sm btn-primary"><i class="fa fa-cog"></i></a>
                                            <a onclick="return confirm('Are You Sure?');" href="<?php echo e(route('courier.delete', $courier->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash-o"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){
            $("#table").DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\ordermanager\resources\views/backend/courier/index.blade.php ENDPATH**/ ?>