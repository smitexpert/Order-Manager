<tr>
    <th>Method</th>
    <th>Amount</th>
    <th>Remind Code</th>
</tr>
<?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->payment_method); ?></td>
        <td><?php echo e($item->amount); ?></td>
        <td><?php echo e($item->remind_code); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\LARAVEL\ordermanager\resources\views/backend/all/payment.blade.php ENDPATH**/ ?>