@foreach ($remarks as $item)
    <tr>
        <td>{{ $item->remark }}</td>
    </tr>
@endforeach